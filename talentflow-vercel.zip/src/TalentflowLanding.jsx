export default function TalentflowLanding() {
  return <div className='p-10 text-3xl'>Talentflow Website ist bereit für Vercel Deployment.</div>
}